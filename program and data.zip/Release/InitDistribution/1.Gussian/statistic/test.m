function test()
    clear;
    global rmin;
    global dr;
    %the range of R
    nr=2000; %number of divided slices of r
    f=load('3D.txt');
    dx=f(2,2)-f(1,2);
    f=f(find(f(:,1)==f(end,1)),2:3); %find out the last picture
    f(:,2)=f(:,2)/dx;
    
%     f=zeros(100,2);
%     f(:,1)=linspace(1,4,100);
%     f(:,2)=abs(-exp(f(:,1)));
    %remove zero point
    f=f(min(find(f(:,2)~=0)):end,:);
    rmin=min(f(:,1));
    rmax=max(f(:,1));
    %divide r uniformly
    r=linspace(rmin,rmax,nr);
    dr=r(2)-r(1);
    g=interp1(f(:,1),f(:,2),r,'spline');
    %plot(r,g,f(:,1),f(:,2),'g*');
    V=r; %store the changing rate at each r
    Vform=V;
    Vbreak=V;
    for i=1:nr %for given r
        %Vform;
        ri=r(i);
        if ri<ceilr(rmin*2^(1/3)) %ri must be larger certain number
            Vform(i)=0;
        else
            rp_max=floorr((ri^3-rmin^3)^(1/3));
            %rp=rmin:dr:rp_max;
            rp=floorr((ri)*2^(-1/3)):dr:rp_max;
            rdp=roundr((ri^3-rp.^3).^(1/3));
            grp=g(round((rp-rmin)/dr+1));
            grdp=g(round((rdp-rmin)/dr+1));
            Vform(i)= dr*sum( grp.*grdp./rdp.^2.*(rp+rdp).^3.*abs(rp-rdp) );
        end
        %Vbreak;
        Vbreak(i)= 2*dr*sum( g(round((ri-rmin)/dr+1))/ri^2*g.*(ri+r).^3.*abs(ri-r) );
    end
    V=Vform-Vbreak;
    plot(r,V,r,Vform,r,Vbreak);
    legend('V','Vform','Vbreak');
    xlabel('V');
    ylabel('difference');
    title('difference function for Gaussian initial distribution');
end

function c= ceilr(r)
    global rmin;
    global dr;
    c=dr*ceil((r-rmin)/dr)+rmin;
end

function f= floorr(r)
    global rmin;
    global dr;
    f=dr*floor((r-rmin)/dr)+rmin;
end

function rd= roundr(r)
    global rmin;
    global dr;
    rd=dr*round((r-rmin)/dr)+rmin;
end
    