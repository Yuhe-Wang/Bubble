%fit whether use Hill function as input
%cut whether to cut out the tail part
function test2(fit,cut)
    global rmin;
    global dr;
    %the range of R
    nr=2000; %number of divided slices of r
    f=load('3D.txt');
    dx=f(2,2)-f(1,2);
    f=f(find(f(:,1)==f(end,1)),2:3); %find out the last picture
    f(:,2)=f(:,2)/dx;
    if cut~=0 %use the original tail part
        f(find(f(:,1)<0.54),2)=0; %set the inital part zero
    end
    
    rmax=max(f(:,1));
    %divide r uniformly
    r=linspace(0,rmax,nr+1);
    dr=r(2)-r(1);
    g=interp1(f(:,1),f(:,2),r,'spline');
    r=r(2:end);
    rmin=r(1);
    g=g(2:end);
    
    if fit==1
        %hill1 function to replace g
        n=2.54947;
        g=3.26368e6+(-153.8-3.26368e6)*r.^n./(0.0528^n+r.^n);
        if cut==1
            g(find(r<0.54))=0; %set the inital part zero
        else
            g(find(r<0.54))=g(max(find(r<0.54))+1); %set the initial part constant
        end
    elseif fit==2
         g(:)=3000; %choose a constant function to test
    end
        
    figure(1);
    plot(r,g,f(:,1),f(:,2),'g-');
    legend('fitting g(r)','original g(r)');
    title('the final distribution');
    xlabel('x');
    ylabel('g');
    
    nrs=3; %starting point of calculated V
    V=r; %store the changing rate at each r
    V(:)=0;
    Vform=V;
    Vbreak=V;
    for i=nrs:nr %for given r
        %Vform;
        ri=r(i);
        
        rp=floorr(ri*2^(-1/3)):dr:ri-dr;
        rdp=roundr((ri^3-rp.^3).^(1/3));
        grp=g(round(rp/dr));
        grdp=g(round(rdp/dr));
        Vform(i)= dr*sum( grp.*grdp./rdp.^2.*(rp+rdp).^3.*abs(rp-rdp) );
        %Vbreak;
        ingrand=g(round(ri/dr))/ri^2*g.*(ri+r).^3.*abs(ri-r);
        Vbreak(i)= dr*sum( ingrand(1:round(ri/dr)) ); %sum first part
        %Vbreak(i)= dr*sum( ingrand(1:end) ); %sum all 
        %Vbreak(i)= 2*dr*sum( ingrand(round(ri/dr):end) ); %sum rest part
    end
    V=Vform-Vbreak;
    figure(2);
    plot(r,V,r,Vform,r,Vbreak);
    grid on;
    legend('R','Rform','Rbreak');
    xlabel('a');
    ylabel('collison rate');
    title('collision rate for Gaussian initial distribution');
end

function c= ceilr(r)
    global rmin;
    global dr;
    c=dr*ceil(r/dr);
end

function f= floorr(r)
    global rmin;
    global dr;
    f=dr*floor(r/dr);
end

function rd= roundr(r)
    global rmin;
    global dr;
    rd=dr*round(r/dr);
end
    