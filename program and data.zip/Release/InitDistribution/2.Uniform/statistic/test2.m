function test2()
    clear;
    global rmin;
    global dr;
    %the range of R
    nr=2000; %number of divided slices of r
    f=load('3D.txt');
    dx=f(2,2)-f(1,2);
    f=f(find(f(:,1)==f(end,1)),2:3); %find out the last picture
    f(:,2)=f(:,2)/dx;
    
    rmax=max(f(:,1));
    %divide r uniformly
    r=linspace(0,rmax,nr+1);
    dr=r(2)-r(1);
    g=interp1(f(:,1),f(:,2),r,'spline');
    r=r(2:end);
    rmin=r(1);
    g=g(2:end);
    %plot(r,g,f(:,1),f(:,2),'g-');
    nrs=4;
    V=r; %store the changing rate at each r
    V(:)=0;
    Vform=V;
    Vbreak=V;
    for i=nrs:nr %for given r
        %Vform;
        ri=r(i);
        
        %rp_max=floorr((ri^(-1/3));
        %rp=rmin:dr:rp_max;
        rp=floorr(ri*2^(-1/3)):dr:ri-dr;
        rdp=roundr((ri^3-rp.^3).^(1/3));
        grp=g(round(rp/dr));
        grdp=g(round(rdp/dr));
        Vform(i)= dr*sum( grp.*grdp./rdp.^2.*(rp+rdp).^3.*abs(rp-rdp) );
        %Vbreak;
        ingrand=g(round(ri/dr))/ri^2*g.*(ri+r).^3.*abs(ri-r);
        Vbreak(i)= dr*sum( ingrand(1:round(ri/dr)) );
        %Vbreak(i)= 2*dr*sum( ingrand(round(ri/dr):end) );
    end
    V=Vform-Vbreak;
    plot(r,V,r,Vform,r,Vbreak);
    legend('V','Vform','Vbreak');
    xlabel('V');
    ylabel('difference');
    title('difference function for Gaussian initial distribution');
end

function c= ceilr(r)
    global rmin;
    global dr;
    c=dr*ceil(r/dr);
end

function f= floorr(r)
    global rmin;
    global dr;
    f=dr*floor(r/dr);
end

function rd= roundr(r)
    global rmin;
    global dr;
    rd=dr*round(r/dr);
end
    