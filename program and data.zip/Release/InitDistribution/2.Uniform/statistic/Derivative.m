%solve df(x,t)/dt and df(x,t)/x
f=load('3D.txt');
dx=f(2,2)-f(1,2);
xm=max(f(:,2));
nd=1; %density parameter of the grading points
[t,x]=meshgrid(0:1/nd:100,0:dx/nd:xm);
z=griddata(f(:,1),f(:,2),f(:,3),t,x);
z(find(isnan(z)==1)) = 0;
%surf(t,x,z);

%df(x,t)/dx
df_dx=zeros(size(z));
for i=2:(numel(z(:,1))-1)
    df_dx(i,:)=(z(i+1,:)-z(i-1,:))/2/dx*nd;
end

%df(x,t)/dt
df_dt=zeros(size(z));
for i=2:(numel(z(1,:))-1)
    df_dt(:,i)=(z(:,i+1)-z(:,i-1))/2*nd;
end

t=t(2:end,2:end);
x=x(2:end,2:end);
df_dx=df_dx(2:end,2:end);
df_dt=df_dt(2:end,2:end);

figure(1);
surf(t,x,df_dx);
title('df/dx');
figure(2);
surf(t,x,df_dt);
title('-df/dt');

