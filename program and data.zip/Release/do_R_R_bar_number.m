clear;clc;
%sta is 101*3 matrix. First index is time step, and second index is data
%type. 1 means average size, 2 means the deviation of the size, 3 means
%current bubble number.
sta=load('status_ave.txt'); 
%f is the 3D demensional statistic data
f=load('statistic\3D.txt');
c=tabulate(f(:,1)); %find out how many intervals at each time
%c=c(:,2); 
index=1; %index at time t in matrix f
for t=1:101
    nx=c(t,2); %number of bins at time t
    %process x-> x/x_bar
    f(index:index+nx-1,2)=f(index:index+nx-1,2)/sta(t,1);
    
    %process f-> f*x_bar/N
    f(index:index+nx-1,3)=f(index:index+nx-1,3)*sta(t,1);
    
    index=index+nx;
end
xm=max(f(:,2));
nx=100; %how many grids in x direction
[t,x]=meshgrid(0:100,0:xm/nx:xm);
z=griddata(f(:,1),f(:,2),f(:,3),t,x);
surf(x,t,z); %draw the 3D surface
%output the final f(x,t), which will be drawn in Origin for better effect
save f_a_bar.txt -ascii f;
title('f(x,t)');
xlabel('x');
ylabel('t');
zlabel('f');

